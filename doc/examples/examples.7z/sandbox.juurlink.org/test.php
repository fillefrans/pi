<html>
<head>
  <title>Checkbox test</title>
  <style type="text/css">
label { 
  cursor: pointer; 
}
  </style>
</head>
<body>
  <br />
  <br />
  <br />
  <br />
  <br />
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
<form onclick="">
<label for="test"><input type="checkbox" id="test" name="test" />Radio button label</label>
</form>
</body>
</html>
